<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
?>

    <div class="px-4 pt-5 my-5 text-center border-bottom">
        <h1 class="display-4 fw-bold">Instituição SkyNet</h1>
        <div class="col-lg-6 mx-auto">
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
                <a href="desktop.php" class="btn btn-outline-dark btn-lg px-4">Ver Desktops</a>
                <a href="sala.php" class="btn btn-outline-dark btn-lg px-4">Ver Salas</a>
            </div>
        </div>
        <div class="overflow-hidden" style="max-height: 30vh;">
            <div class="container px-5">
                <img src="images/tecno.png" class="img-fluid border rounded-3 shadow-lg mb-4" alt="Example image" width="700" height="500" loading="lazy">
            </div>
        </div>
    </div>

<?php

require_once FOOTER_TEMPLATE;
