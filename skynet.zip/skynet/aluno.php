<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
require_once 'Crud.php';

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = [];
$select = $crud->select('vw_descricao_aluno',$dados);
$select->fetch_assoc();

?>
    <header>
        <div class="row">

            <div class="col-sm">
                <h2>Alunos</h2>
            </div>
            <div class="col-sm-6 text-end h6">
                <a class="btn btn-success" href="newAluno.php">
                    <i class="bi bi-window-plus"></i> Novo Aluno
                </a>
                <a class="btn btn-secondary" href="">
                    <i class="bi bi-arrow-clockwise"></i> Atualizar
                </a>
            </div>

        </div>
        <hr>
    </header>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">RA</th>
            <th scope="col">Nome</th>
            <th scope="col">Graduação</th>
            <th scope="col">Desktop</th>
            <th scope="col">Modelo Desktop</th>
            <th scope="col">Criado em</th>
            <th scope="col" class="text-end">Opções</th>
        </tr>
        </thead>
        <tbody class="table-group-divider">
        <?php
        if($select->num_rows > 0){
            foreach ($select as $desktop){

                ?>
                <tr>
                    <td><?php echo $desktop['RA'] ?></td>
                    <td><?php echo $desktop['Nome'] ?></td>
                    <td><?php echo $desktop['Graduação'] ?></td>
                    <td><?php echo $desktop['Desktop'] ?></td>
                    <td><?php echo $desktop['Modelo'] ?></td>
                    <td><?php echo $desktop['criado'] ?></td>
                    <td class="text-end">
                        <a class="btn btn-sm btn-warning" href="editaluno.php?cpf=<?php echo $desktop['cpf'];?>">
                            <i class="bi bi-pencil-square"></i> Editar
                        </a>
                    </td>
                </tr>
                <?php
            }
        }else{
            echo "
                    <tr>
                        <td colspan='4'>Nenhum registro encontrado.</td>
                    </tr>
                    ";
        }
        ?>
        </tbody>
    </table>
<?php

require_once FOOTER_TEMPLATE;
