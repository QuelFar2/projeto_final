<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = ['id' => $_GET['id']];
$select = $crud->select('desktop',$dados);
$select->fetch_assoc();


if (isset($_POST) and !empty($_POST)) {
    $update = $_POST;
    $sel = $crud->update('desktop', $update,$dados['id']);
    header('location: desktop.php');
}

?>

<div class="text-center">
    <h1>Editar</h1>
</div>
<br>
<?php
foreach ($select as $desktop){
?>
<form class="row g-3 needs-validation" method="post">
    <h1>Desktop = <?php echo $desktop['id'] ?></h1>
    <div class="col-md-12">
        <label for="marca" class="form-label">Marca</label>
        <input type="text" class="form-control" name="marca" id="marca" value="<?php echo $desktop['marca'] ?>" required >
    </div>
    <div class="col-md-12">
        <label for="modelo" class="form-label">Modelo</label>
        <input type="text" class="form-control" name="modelo" id="modelo" value="<?php echo $desktop['modelo'] ?>" required>
    </div>
    <div class="col-md-12">
        <label for="placa_mae" class="form-label">Placa Mãe</label>
        <input type="text" class="form-control" name="placa_mae" id="placa_mae" value="<?php echo $desktop['placa_mae'] ?>" required>
    </div>
    <div class="col-md-12">
        <label for="processador" class="form-label">Processador</label>
        <input type="text" class="form-control" name="processador" id="processador" value="<?php echo $desktop['processador'] ?>" required>
    </div>
    <div class="col-md-12">
        <label for="ram" class="form-label">Memória RAM</label>
        <input type="text" class="form-control" name="ram" id="ram" value="<?php echo $desktop['ram'] ?>" required>
    </div>
    <div class="col-md-12">
        <label for="hd" class="form-label">Armazenamento</label>
        <input type="text" class="form-control" name="hd" id="hd" value="<?php echo $desktop['hd'] ?>" required>
    </div>
    <hr>
    <h1>Monitor</h1>
    <div class="col-md-12">
        <label for="marca_monitor" class="form-label">Marca</label>
        <input type="text" class="form-control" name="marca_monitor" id="marca_monitor" value="<?php echo $desktop['marca_monitor'] ?>" required>
    </div>
    <div class="col-md-12">
        <label for="modelo_monitor" class="form-label">Modelo</label>
        <input type="text" class="form-control" name="modelo_monitor" id="modelo_monitor" value="<?php echo $desktop['modelo_monitor'] ?>" required>
    </div>
    <div class="col-12">
        <button class="btn btn-primary" type="submit"><i class="bi bi-pc-display"></i> Salvar</button>
    </div>
</form>
<?php
}
require_once FOOTER_TEMPLATE;

?>
