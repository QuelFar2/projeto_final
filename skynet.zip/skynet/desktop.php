<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;
require_once 'Crud.php';
$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = [];
$select = $crud->select('vw_descricao_desktop',$dados);
$select->fetch_assoc();

?>
        <header>
            <div class="row">

                <div class="col-sm">
                    <h2>Desktops</h2>
                </div>
                <div class="col-sm-6 text-end h6">
                    <a class="btn btn-success" href="newdesktop.php">
                        <i class="bi bi-window-plus"></i> Novo Desktop
                    </a>
                    <a class="btn btn-secondary" href="">
                        <i class="bi bi-arrow-clockwise"></i> Atualizar
                    </a>
                </div>

            </div>
            <hr>
        </header>
        <table class="table">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Marca</th>
                <th scope="col">Modelo</th>
                <th scope="col">Placa Mãe</th>
                <th scope="col">Processador</th>
                <th scope="col">Memória RAM</th>
                <th scope="col">Armazenamento</th>
                <th scope="col" class="text-end">Opções</th>
            </tr>
            </thead>
            <tbody class="table-group-divider">
            <?php
                if($select->num_rows > 0){
                    foreach ($select as $desktop){

                    ?>
                    <tr>
                        <td><?php echo $desktop['id'] ?></td>
                        <td><?php echo $desktop['marca'] ?></td>
                        <td><?php echo $desktop['modelo'] ?></td>
                        <td><?php echo $desktop['placa_mae'] ?></td>
                        <td><?php echo $desktop['processador'] ?></td>
                        <td><?php echo $desktop['ram'] ?></td>
                        <td><?php echo $desktop['hd'] ?></td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-success" href="" data-bs-toggle="modal" data-bs-target="#exampleModal_<?php echo $desktop['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                        <div class="modal fade" id="exampleModal_<?php echo $desktop['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><strong>ID :</strong> <?php echo $desktop['id'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body text-left">
                                        <ul class="list-group list-group-flush">
                                        <li class='list-group-item'><strong>Aluno : </strong><?php echo $desktop['nome_aluno'] ?></li>
                                        <li class='list-group-item'><strong>Graduação : </strong><?php echo $desktop['graduacao'] ?></li>
                                        <li class='list-group-item'><strong>Marca : </strong><?php echo $desktop['marca'] ?></li>
                                        <li class='list-group-item'><strong>Modelo : </strong><?php echo $desktop['modelo'] ?></li>
                                        <li class='list-group-item'><strong>Placa Mãe : </strong><?php echo $desktop['placa_mae'] ?></li>
                                        <li class='list-group-item'><strong>Processador : </strong><?php echo $desktop['processador'] ?></li>
                                        <li class='list-group-item'><strong>Memória RAM : </strong><?php echo $desktop['ram'] ?></li>
                                        <li class='list-group-item'><strong>Armazenamento : </strong><?php echo $desktop['hd'] ?></li>
                                        <li class='list-group-item'><strong>Estado : </strong><?php echo $desktop['estado_pc'] ?></li>
                                        <li class='list-group-item'><strong>Marca Monitor : </strong><?php echo $desktop['marca_monitor'] ?></li>
                                        <li class='list-group-item'><strong>Modelo Monitor : </strong><?php echo $desktop['modelo_monitor'] ?></li>
                                        </ul>
                                    </div>
                                    <div class="modal-footer">
                                        <a class="btn btn btn-warning" href="editdesktop.php?id=<?php echo $desktop['id'];?>">
                                            <i class="bi bi-pencil-square"></i> Editar
                                        </a>
                                        <a class="btn btn btn-danger" href="delPc.php?id=<?php echo $desktop['id'];?>">
                                            <i class="bi bi-trash"></i> Excluir
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
            <?php
                    }
                }else{
                    echo "
                    <tr>
                        <td colspan='4'>Nenhum registro encontrado.</td>
                    </tr>
                    ";
                }
                ?>
            </tbody>
        </table>
<?php

require_once FOOTER_TEMPLATE;