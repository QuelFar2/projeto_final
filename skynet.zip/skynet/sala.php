<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dados = $_POST;
$select = $crud->select('sala',$dados);
$select->fetch_assoc();

?>
<header>
    <div class="row">

        <div class="col-sm">
            <h2>Salas</h2>
        </div>
        <div class="col-sm-6 text-end h6">
            <a class="btn btn-success" href="newsala.php">
                <i class="bi bi-window-plus"></i> Nova Sala
            </a>
            <a class="btn btn-secondary "href="">
                <i class="bi bi-arrow-clockwise"></i> Atualizar
            </a>
        </div>

    </div>
    <hr>
</header>
<?php
if($select->num_rows > 0){
    foreach ($select as $sala){
        $call = $crud->callFunction('fnc_quantidade_pc_sala',$sala['id']);
        foreach ($call as $func){
            if( $func["fnc_quantidade_pc_sala($sala[id])"] > 0){
                $see = $func["fnc_quantidade_pc_sala($sala[id])"];
            }else{
                $see = 0;
            }
        }
        ?>
        <div class="card">
            <div class="card-header">
                <i class="bi bi-person-lines-fill"></i> <?php echo $see;?>
            </div>
            <div class="card-body">
                <h5 class="card-title"><?php echo $sala['graduacao'] ?></h5>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo $sala['id'] ?>">
                    Ver sala
                </button>
            </div>
        </div>

        <div class="modal fade" id="staticBackdrop<?php echo $sala['id'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel<?php echo $sala['id'] ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel"><?php echo $sala['graduacao'] ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        ...
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Understood</button>
                    </div>
                </div>
            </div>
        </div>

        <br>
        <?php
    }
}else{
    echo "
                    <tr>
                        <td colspan='4'>Nenhum registro encontrado.</td>
                    </tr>
                    ";
}
?>
<?php

require_once FOOTER_TEMPLATE;

?>
