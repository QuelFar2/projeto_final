<?php
require_once 'config.php';
require_once 'Crud.php';

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
if (isset($_POST) and !empty($_POST)) {
    $dados = $_POST;
    $select = $crud->select('pessoa', $dados);

    if ($select->num_rows > 0){
        session_start();
        foreach ($select as $people){
            $_SESSION['cpf'] = $people['cpf'];
            $_SESSION['user'] = $people['nome'];
        }

        header('location: view.php');
    }else{
        $_SESSION['erro'] = "Nome de Usuário ou Senha inválidos";
    }
}

?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
    <title>SkyNet</title>
</head>
<body>

<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    <div class="row align-items-center g-lg-5 py-5">
        <div class="col-lg-7 text-center text-lg-start">
            <h1 class="display-4 fw-bold lh-1 mb-3"><i class="bi bi-cone-striped"></i> Instituição SkyNet</h1>
        </div>
        <div class="col-md-10 mx-auto col-lg-5">
            <form class="p-4 p-md-5 border rounded-3 bg-light" method="post">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="cpf" id="floatingInput" placeholder="CPF" autocomplete="off">
                    <label for="floatingInput">CPF</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" name="senha" id="floatingPassword" placeholder="Senha">
                    <label for="floatingPassword">Senha</label>
                </div>
                <button class="w-100 btn btn-lg btn-primary" type="submit"><i class="bi bi-arrow-right-circle"></i> Entrar</button>
                <?php
                    if (isset($_SESSION['erro'])){
                ?>
                        <hr class="my-4">
                        <div class="alert alert-danger" role="alert">
                            <?php echo $_SESSION['erro'] ?>
                        </div>
                        <?php } ?>
            </form>
        </div>
    </div>
</div>

</body>
<?php
require_once FOOTER_TEMPLATE;
?>