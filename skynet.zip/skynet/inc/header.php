<?php

require_once 'config.php';
require_once 'Crud.php';

session_start();

if(!isset($_SESSION['user']) or !isset($_SESSION['cpf'])){
    header('location: semAcesso.php');
}

?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
    <title>SkyNet</title>
</head>
<body >
  <header class="d-flex flex-wrap justify-content-center py-4 mb-4 border-bottom bg-dark">
      <div class="container">
          <div class="row gx-5 align-items-center">
            <div class="col">
              <a href="view.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-light text-decoration-none">
                <h1><i class="bi bi-plugin"></i> SKYNET</h1>

              </a>
            </div>

            <div class="col">
              <ul class="nav nav-pills">
                <li class="nav-item">
                    <a class="nav-link text-light" aria-current="page" href="view.php"><i class="bi bi-house"></i> Home</a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bi bi-pc-display-horizontal"></i> Desktop
                  </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="desktop.php">Visão Geral</a></li>
                      <li><a class="dropdown-item" href="newdesktop.php">Cadastrar</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown ">
                  <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bi bi-book"></i> Salas
                  </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <li><a class="dropdown-item" href="sala.php">Visão Geral</a></li>
                      <li><a class="dropdown-item" href="newsala.php">Cadastrar</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <i class="bi bi-person"></i> <?php echo $_SESSION['user']; ?>
                  </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="newAluno.php">Cadastrar Alunos</a></li>
                      <li><a class="dropdown-item" href="#">Configurações</a></li>
                      <li><a class="dropdown-item" href="aluno.php">Informações</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="logout.php"><i class="bi bi-door-open-fill"></i>Logout</a></li>
                    </ul>
                </li>
              </ul>
            </div>
          </div>
    </div>
  </header>
  <div class="container">