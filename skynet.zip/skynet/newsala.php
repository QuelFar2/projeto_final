<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);

if (isset($_POST) and !empty($_POST)) {
    $dados = $_POST;
    $crud->insert('sala', $dados);
    header('location: sala.php');
}

?>

<div class="text-center">
    <h1>CADASTRAR</h1>
</div>
<br>
<form class="row g-3 needs-validation" method="post">
    <h1>Sala</h1>
    <div class="col-md-12">
        <label for="validationCustom01" class="form-label">Graduação</label>
        <input type="text" class="form-control" name="graduacao" id="validationCustom01" required>
    </div>
    <div class="b-example-divider"></div>
    <div class="col-12">
        <button class="btn btn-primary" type="submit"><i class="bi bi-bookmark-plus"></i> Cadastrar</button>
    </div>
</form>
<?php

require_once FOOTER_TEMPLATE;

?>
