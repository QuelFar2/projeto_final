<?php

require_once 'config.php';
require_once HEADER_TEMPLATE;

$crud = new Crud(DB_HOST,DB_PORT,DB_NAME,DB_USER,DB_PASSWORD,DB_CHAR);
$dad = ['cpf' => $_GET['cpf']];
$select = $crud->select('sala',[]);
$pea = $crud->select('pessoa',$dad);
$select->fetch_assoc();

if(isset($_POST) and !empty($_POST)){
    $dados = $_POST;
    $graduacao = ['id_sala' => $_POST['graduacao']];
    unset($dados['graduacao']);
    $pessoa = $crud->update('pessoa',$dados,$_GET['cpf']);
    $aluno = $crud->update('aluno',$graduacao,$_POST['cpf']);
    header('location: aluno.php');
}

?>

    <div class="text-center">
        <h1>Cadastrar</h1>
    </div>
    <br>
    <?php
    foreach ($pea as $pessoa){
        ?>
    <form class="row g-3 needs-validation" method="post">
        <h1>Aluno</h1>
        <div class="col-md-6">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" class="form-control" name="nome" id="nome" value="<?php echo $pessoa['nome'] ?>" autocomplete="off" required>
        </div>
        <div class="col-md-6">
            <label for="cpf" class="form-label">CPF</label>
            <input type="text" class="form-control" name="cpf" id="cpf" value="<?php echo $pessoa['cpf'] ?>" autocomplete="off" required>
        </div>
        <div class="col-md-6">
            <label for="email" class="form-label">E-mail</label>
            <input type="text" class="form-control" name="email" id="email" value="<?php echo $pessoa['email'] ?>" autocomplete="off" required>
        </div>
        <div class="col-md-6">
            <label for="senha" class="form-label">Senha</label>
            <input type="password" class="form-control" name="senha" id="senha" value="<?php echo $pessoa['senha'] ?>" autocomplete="off" required>
        </div>
        <div class="col-md-8">
            <label for="endereco" class="form-label">Endereço</label>
            <input type="text" class="form-control" name="endereco" id="endereco" value="<?php echo $pessoa['endereco'] ?>" autocomplete="off" required>
        </div>
        <div class="col-md-4">
            <label for="telefone" class="form-label">Telefone</label>
            <input type="text" class="form-control" name="telefone" id="telefone" value="<?php echo $pessoa['telefone'] ?>" autocomplete="off" required>
        </div>
        <hr>
        <h1>Graduação</h1>

        <select class="form-select" aria-label="Default select example" name="graduacao">
            <option selected value="">Selecione...</option>
            <?php
            }
            foreach ($select as $sala){
                ?>
                <option value="<?php echo $sala['id'];?>"><?php echo $sala['graduacao'];?></option>
                <?php
            }
            ?>


        </select>


        <div class="col-12">
            <button class="btn btn-primary" type="submit"><i class="bi bi-person"></i> Salvar</button>
        </div>
    </form>

<?php

require_once FOOTER_TEMPLATE;