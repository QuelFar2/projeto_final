<?php

require_once 'config.php';

?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.2/font/bootstrap-icons.css">
        <title>SkyNet</title>
    </head>
    <body>

    <div class="container my-5">
        <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
            <div class="col-lg-7 p-3 p-lg-5 pt-lg-3">
                <h1 class="display-4 fw-bold lh-1">Erro de AUTENTICAÇÃO</h1>
                <h3 class="">Você não tem permissão para acessar está página, Favor realizar o login</h3>
                <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4 mb-lg-3">
                    <a type="button" href="index.php" class="btn btn-primary btn-lg px-4 me-md-2 fw-bold">LOGIN</a>
                </div>
            </div>
            <div class="col-lg-4 offset-lg-1 p-0 overflow-hidden shadow-lg">
                <img class="rounded-lg-3 img-fluid" src="images/404.png" alt="Erro de autenticação">
            </div>
        </div>
    </div>

    </body>
<?php

require_once FOOTER_TEMPLATE;

?>